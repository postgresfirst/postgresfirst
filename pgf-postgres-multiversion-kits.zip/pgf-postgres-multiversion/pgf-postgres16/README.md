# pgf-postgres16 – packaging kit (PostgreSQL 16 default)

Builds Debian and RPM packages that ship:
- /usr/bin/pgf-postgres-setup (wrapper defaulting to PostgreSQL 16)
- /usr/bin/pgf-postgres (helper CLI)
- /usr/lib/pgf-postgres/pgf-postgres-installer.sh (multi-distro installer)
- /etc/pgf-postgres/config (defaults)

## Build .deb
```bash
sudo apt-get update && sudo apt-get install -y build-essential debhelper devscripts
debuild -us -uc
# Result: ../pgf-postgres16_1.0.0-1_all.deb
```

## Build .rpm
```bash
sudo dnf -y install rpm-build
tar czf /tmp/pgf-postgres16-1.0.0.tar.gz --transform 's,^,pgf-postgres16-1.0.0/,' installer scripts etc debian rpm LICENSE README.md
rpmbuild -ba rpm/pgf-postgres16.spec --define "_sourcedir /tmp" --define "_version 1.0.0"
# Result: ~/rpmbuild/RPMS/noarch/pgf-postgres16-1.0.0-1.noarch.rpm
```

## Use
```bash
sudo pgf-postgres-setup -y         # installs PostgreSQL 16 by default
sudo pgf-postgres-setup --version 16 --allow 10.0.0.0/8 -y
pgf-postgres status
```
