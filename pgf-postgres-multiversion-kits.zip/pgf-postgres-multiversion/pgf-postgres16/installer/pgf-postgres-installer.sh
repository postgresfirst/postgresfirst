#!/usr/bin/env bash
set -euo pipefail

PGF_NAME="PGF Postgres"
DEFAULT_VERSION="16"
USE_PGDG=true
DATA_DIR_DEFAULT=""
PORT_DEFAULT="5432"

BOLD="\033[1m"; DIM="\033[2m"; GREEN="\033[32m"; RED="\033[31m"; YELLOW="\033[33m"; NC="\033[0m"

die(){ echo -e "${RED}ERROR:${NC} $*" >&2; exit 1; }
info(){ echo -e "${GREEN}==>${NC} $*"; }
note(){ echo -e "${YELLOW}--${NC} $*"; }

require_root(){ if [[ $EUID -ne 0 ]]; then die "Please run as root (use sudo)."; fi; }

usage(){
cat <<EOF
${BOLD}${PGF_NAME} Installer${NC}
Usage: sudo pgf-postgres-setup [options]
Options:
  --version N         PostgreSQL major version (default: ${DEFAULT_VERSION})
  --port N            Port (default: ${PORT_DEFAULT})
  --data-dir PATH     Custom PGDATA path
  --allow CIDR        Append pg_hba rule (repeatable)
  --use-distro-repo   Use distro repos instead of PGDG
  --uninstall         Remove PGF Postgres (keeps data unless --purge)
  --purge             With --uninstall, also remove data directories
  -y, --yes           Assume yes
  -h, --help          This help
EOF
}

VERSION="${DEFAULT_VERSION}"; PORT="${PORT_DEFAULT}"; ALLOW_RULES=(); ASSUME_YES=false; UNINSTALL=false; PURGE=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --version) VERSION="${2:?}"; shift 2;;
    --port) PORT="${2:?}"; shift 2;;
    --data-dir) DATA_DIR_DEFAULT="${2:?}"; shift 2;;
    --allow) ALLOW_RULES+=("$2"); shift 2;;
    --use-distro-repo) USE_PGDG=false; shift;;
    --uninstall) UNINSTALL=true; shift;;
    --purge) PURGE=true; shift;;
    -y|--yes) ASSUME_YES=true; shift;;
    -h|--help) usage; exit 0;;
    *) echo "Forwarding unknown option: $1"; shift;;
  esac
done

require_root
source /etc/os-release || die "Cannot read /etc/os-release"
OS_ID="${ID}"; OS_VER="${VERSION_ID:-}"; OS_CODENAME="${VERSION_CODENAME:-}"

case "$OS_ID" in
  ubuntu|debian) FAMILY="debian" ;;
  rhel|rocky|almalinux|centos) FAMILY="rhel" ;;
  amzn) FAMILY="rhel"; OS_ID="amzn" ;;
  sles|opensuse-leap|opensuse-tumbleweed|opensuse) FAMILY="suse" ;;
  arch) FAMILY="arch" ;;
  *) die "Unsupported Linux distribution: ${OS_ID}" ;;
esac

if [[ "$UNINSTALL" == true ]]; then
  info "Uninstalling ${PGF_NAME}..."
  case "$FAMILY" in
    debian) systemctl stop postgresql || true; apt-get -y remove --purge "postgresql*" "pgdg-keyring" || true; apt-get -y autoremove || true; rm -f /etc/apt/sources.list.d/pgdg.list /etc/apt/keyrings/postgresql.gpg || true ;;
    rhel) systemctl stop "postgresql-${VERSION}" || true; dnf -y remove "postgresql*" "pgdg-redhat-repo" || true ;;
    suse) systemctl stop "postgresql" || true; zypper -n rm -u postgresql || true; zypper -n rr pgdg 2>/dev/null || true ;;
    arch) systemctl stop postgresql || true; pacman -Rns --noconfirm postgresql || true ;;
  esac
  rm -f /usr/local/bin/pgf-postgres || true
  if [[ "$PURGE" == true ]]; then rm -rf /var/lib/pgsql /var/lib/postgresql || true; fi
  info "Uninstall complete."; exit 0
fi

if [[ "$ASSUME_YES" == false ]]; then
  echo -e "${BOLD}${PGF_NAME}${NC} will install PostgreSQL ${VERSION} on ${OS_ID} ${OS_VER}."
  read -r -p "Proceed? [y/N] " ans; [[ "$ans" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 1; }
fi

add_hba_rules(){ local hba="$1"; for cidr in "${ALLOW_RULES[@]}"; do if ! grep -qE "^[[:space:]]*host[[:space:]]+all[[:space:]]+all[[:space:]]+${cidr//\//\\/}[[:space:]]+md5" "$hba" 2>/dev/null; then echo "host all all $cidr md5" >> "$hba"; note "Added pg_hba rule: host all all $cidr md5"; fi; done; }

install_helper_cli(){
  cat >/usr/local/bin/pgf-postgres <<'EOS'
#!/usr/bin/env bash
set -euo pipefail
UNIT_GUESSES=("postgresql" "postgresql-17" "postgresql-16" "postgresql-15" "postgresql-14" "postgresql-13")
unit=""
for u in "${UNIT_GUESSES[@]}"; do
  if systemctl list-unit-files | grep -q "^${u}\.service"; then unit="$u"; break; fi
done
if [[ -z "$unit" ]]; then echo "Cannot locate PostgreSQL systemd unit."; exit 1; fi
case "${1:-}" in
  start) sudo systemctl start "$unit";;
  stop) sudo systemctl stop "$unit";;
  restart) sudo systemctl restart "$unit";;
  status|"") systemctl status "$unit";;
  logs) journalctl -u "$unit" -e;;
  *) echo "Usage: pgf-postgres [start|stop|restart|status|logs]"; exit 2;;
esac
EOS
  chmod +x /usr/local/bin/pgf-postgres
  info "Installed helper CLI: /usr/local/bin/pgf-postgres"
}

case "$FAMILY" in
  debian)
    info "Installing prerequisites..."; apt-get update -y; apt-get install -y curl ca-certificates gnupg lsb-release
    if [[ "$USE_PGDG" == true ]]; then
      info "Adding PGDG apt repo..."; install -d -m 0755 /etc/apt/keyrings
      curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc | gpg --dearmor -o /etc/apt/keyrings/postgresql.gpg
      echo "deb [signed-by=/etc/apt/keyrings/postgresql.gpg] http://apt.postgresql.org/pub/repos/apt ${OS_CODENAME}-pgdg main" > /etc/apt/sources.list.d/pgdg.list
      apt-get update -y
    fi
    info "Installing PostgreSQL ${VERSION}..."; apt-get install -y "postgresql-${VERSION}" "postgresql-client-${VERSION}"
    CONF_DIR="/etc/postgresql/${VERSION}/main"; PG_CONF="${CONF_DIR}/postgresql.conf"; HBA_CONF="${CONF_DIR}/pg_hba.conf"
    sed -i "s/^#*port.*/port = ${PORT}/" "$PG_CONF"; if [[ ${#ALLOW_RULES[@]} -gt 0 ]]; then sed -i "s/^#*listen_addresses.*/listen_addresses = '*'/" "$PG_CONF"; fi
    add_hba_rules "$HBA_CONF"; systemctl enable postgresql; systemctl restart postgresql; install_helper_cli
    ;;
  rhel)
    info "Installing prerequisites..."; dnf -y install curl ca-certificates
    if [[ "$USE_PGDG" == true ]]; then RHELVER="$(rpm -E %{rhel})"; dnf -y install "https://download.postgresql.org/pub/repos/yum/reporpms/EL-${RHELVER}-$(uname -m)/pgdg-redhat-repo-latest.noarch.rpm"; dnf -qy module disable postgresql || true; fi
    info "Installing PostgreSQL ${VERSION} server..."; dnf -y install "postgresql${VERSION//./}-server"
    "/usr/pgsql-${VERSION}/bin/postgresql-${VERSION}-setup" initdb
    PG_CONF="/var/lib/pgsql/${VERSION}/data/postgresql.conf"; HBA_CONF="/var/lib/pgsql/${VERSION}/data/pg_hba.conf"
    sed -i "s/^#*port.*/port = ${PORT}/" "$PG_CONF"; if [[ ${#ALLOW_RULES[@]} -gt 0 ]]; then sed -i "s/^#*listen_addresses.*/listen_addresses = '*'/" "$PG_CONF"; fi
    add_hba_rules "$HBA_CONF"; systemctl enable "postgresql-${VERSION}"; systemctl restart "postgresql-${VERSION}"; install_helper_cli
    ;;
  suse)
    info "Installing prerequisites..."; zypper -n install curl ca-certificates || true
    if [[ "$USE_PGDG" == true ]]; then zypper -n ar -f "https://download.postgresql.org/pub/repos/zypper/${ID}/${VERSION_ID}/$(uname -m)" pgdg || true; zypper -n refresh; fi
    info "Installing PostgreSQL ${VERSION}..."; if ! zypper -n in -y "postgresql${VERSION//./}" ; then zypper -n in -y postgresql; fi
    if [[ ! -d /var/lib/pgsql/data/base && -x /usr/bin/initdb ]]; then sudo -u postgres /usr/bin/initdb -D /var/lib/pgsql/data; fi
    PG_CONF="/var/lib/pgsql/data/postgresql.conf"; HBA_CONF="/var/lib/pgsql/data/pg_hba.conf"
    sed -i "s/^#*port.*/port = ${PORT}/" "$PG_CONF"; if [[ ${#ALLOW_RULES[@]} -gt 0 ]]; then sed -i "s/^#*listen_addresses.*/listen_addresses = '*'/" "$PG_CONF"; fi
    add_hba_rules "$HBA_CONF"; systemctl enable postgresql || true; systemctl restart postgresql || true; install_helper_cli
    ;;
  arch)
    info "Installing PostgreSQL from pacman..."; pacman -Sy --noconfirm postgresql
    install -d -o postgres -g postgres /var/lib/postgres/data; sudo -u postgres initdb -D /var/lib/postgres/data
    PG_CONF="/var/lib/postgres/data/postgresql.conf"; HBA_CONF="/var/lib/postgres/data/pg_hba.conf"
    sed -i "s/^#*port.*/port = ${PORT}/" "$PG_CONF"; if [[ ${#ALLOW_RULES[@]} -gt 0 ]]; then sed -i "s/^#*listen_addresses.*/listen_addresses = '*'/" "$PG_CONF"; fi
    add_hba_rules "$HBA_CONF"; systemctl enable postgresql; systemctl restart postgresql; install_helper_cli
    ;;
esac

echo; info "${PGF_NAME} is installed."
echo -e "${DIM}Tips:${NC}\n  • Check: pgf-postgres status\n  • Start/Stop: pgf-postgres start|stop\n  • psql: sudo -u postgres psql\n  • Version: ${VERSION}"
exit 0
