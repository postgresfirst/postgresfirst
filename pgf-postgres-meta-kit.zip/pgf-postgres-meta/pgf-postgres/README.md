See installer and scripts; supports PG 13–17. Build deb/rpm from debian/ and rpm/.
